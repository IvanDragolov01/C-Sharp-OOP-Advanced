﻿# 9.\*Custom List Iterator

For the print command, you have probably used a **for** loop. Extend your custom list class by making it implement **IEnumerable\&lt;T\&gt;.** This should allow you to iterate your list in a foreach statement.

### Examples

| **Input** | **Output** |
| --- | --- |
| Add aaAdd bbAdd ccMaxMinGreater aaSwap 0 2PrintEND | ccaa2ccbbaa |