﻿**2.** Generic Box of Integer

Use the description of the previous problem but now, test your generic box with Integers.

### Examples

| **Input** | **Output** |
| --- | --- |
| 3712342 | System.Int32: 7System.Int32: 123System.Int32: 42 |