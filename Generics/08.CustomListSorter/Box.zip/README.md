﻿# 8.Custom List Sorter

Extend the previous problem. It should have a **method**** Sort() **which can sort objects of type** CustomList **containing any type that can be compared.** Extend the command list** to support one additional command Sort:

- **Sort** - Sort the elements in the list in ascending order.

### Examples

| **Input** | **Output** |
| --- | --- |
| Add ccAdd bbAdd aaSortPrintEND | aabbcc |