﻿using System.Collections.Generic;

namespace _05.GenericCountMethodStrings
{
	public class Box
	{
		List<string> allElements = new List<string>();
		private int _finalElement;

		public void AddInList(string item)
		{
			allElements.Add(item);
		}

		public int GetFinalElement(string element)
		{
			_finalElement = int.Parse(element);
			return _finalElement;
		}

		public int isEqual()
		{
			int greaterNumbers = 0;

			foreach (string element in allElements)
			{
				int elementValue = int.Parse(element);

				if (elementValue > _finalElement)
				{
					greaterNumbers++;
				}
			}

			return greaterNumbers;
		}
	}
}
