﻿# 4.Generic Swap Method Integers

Use the description of the previous problem but now, test your list of generic boxes with Integers.

### Examples

| **Input** | **Output** |
| --- | --- |
| 37123420 2 | System.Int32: 42System.Int32: 123System.Int32: 7 |