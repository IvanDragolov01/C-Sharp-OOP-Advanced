﻿namespace Solid_Exercise
{
	public enum ErrorLevel
	{
		INFO, WARNING, ERROR, CRITICAL, FATAL
	}
}