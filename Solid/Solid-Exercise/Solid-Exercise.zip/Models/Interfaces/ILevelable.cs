﻿namespace Solid_Exercise
{
	public interface ILevelable
	{
		ErrorLevel Level
		{
			get;
		}
	}
}