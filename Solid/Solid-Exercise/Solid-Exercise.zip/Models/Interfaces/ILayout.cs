﻿namespace Solid_Exercise
{
	public interface ILayout
	{
		string FormatError(IError error);
	}
}
